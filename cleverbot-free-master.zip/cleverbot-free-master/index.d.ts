declare function cleverbot(stimlus: string, context?: string[], language?: string): Promise<string>;
export default cleverbot;